<header>
        <nav class="navbar topo-instagran justify-content-center">
            <a class="navbar-brand" href="/fakeinstagram/posts">
                <img width="90" src="views/img/logo.png" alt="" srcset="">
                Instagram
            </a>

            <ul class="nav">
                <li class="nav-item">
                    <a class="nav-link active" href="/fakeinstagram/formulario-user">Cadastro</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/fakeinstagram/formulario-login-user">Login</a>
                </li>
            </ul>
        </nav>
</header>